## Data Requirement

The project utilizes an employee attrition dataset provided as part of the problem statement. 
No additional third-party or external data sources were used in this analysis.

The dataset contains employee demographic, job-related, satisfaction, and performance-related attributes, which are sufficient to build and evaluate predictive models for employee attrition risk.

All analysis and modeling were performed using the given dataset without external data augmentation to maintain consistency and reproducibility.

Public HR analytics datasets commonly available on platforms such as Kaggle were referenced conceptually for understanding feature definitions, though no external datasets were merged.
