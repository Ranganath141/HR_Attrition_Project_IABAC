 Exploratory Data Analysis – Key Insights (Employee Attrition)

• Employee attrition is imbalanced, with significantly fewer employees leaving than staying, making F1-score and Recall more appropriate than accuracy.

• OverTime is one of the strongest indicators of attrition; employees working overtime show a noticeably higher tendency to leave.

• Younger employees and those with lower total work experience have higher attrition rates compared to more experienced employees.

• Monthly compensation–related features (Hourly Rate and Last Salary Hike Percentage) show an inverse relationship with attrition, indicating compensation dissatisfaction as a key factor.

• Employees with lower job satisfaction, environment satisfaction, and work-life balance scores exhibit higher attrition risk.

• Attrition is higher among employees with fewer years at the current company and shorter tenure in the current role, suggesting early-stage disengagement.

• Certain job roles and departments demonstrate higher attrition patterns, indicating the need for role-specific retention strategies.

• Employees with longer gaps since last promotion tend to show higher attrition, highlighting career stagnation as a risk factor.