## Dataset Source

The employee attrition dataset used in this project is sourced from a publicly available HR analytics dataset. The dataset contains demographic, job-related, and satisfaction-based features commonly used for attrition analysis and predictive modeling.