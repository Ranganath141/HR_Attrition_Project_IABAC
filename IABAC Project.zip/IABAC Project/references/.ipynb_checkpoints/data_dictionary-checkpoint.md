## Data Dictionary – Employee Attrition Dataset

- Age: Age of the employee in years
- Gender: Gender of the employee
- EmpDepartment: Department where the employee works
- EmpJobRole: Job role of the employee
- EmpJobLevel: Job level or hierarchy position
- EmpJobSatisfaction: Employee satisfaction with job (1–4)
- EmpEnvironmentSatisfaction: Satisfaction with work environment (1–4)
- EmpWorkLifeBalance: Work-life balance rating (1–4)
- PerformanceRating: Performance evaluation score
- OverTime: Indicates whether employee works overtime (Yes/No)
- EmpLastSalaryHikePercent: Percentage salary hike in last time.
- TotalWorkExperienceInYears: Total professional experience in the field.
- Attrition: Target variable indicating whether employee left (Yes/No)