## Methodology Notes

- Logistic Regression was used as the primary predictive model due to its interpretability and effectiveness on imbalanced datasets.
- Class imbalance was handled using class weighting and threshold tuning.
- Model evaluation prioritized recall for the minority attrition class based on business impact.
- Ensemble models were evaluated for comparison but not selected due to lower minority-class recall.
