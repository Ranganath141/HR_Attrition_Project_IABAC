## Tools and Libraries

- Python
- Pandas, NumPy for data manipulation
- Matplotlib, Seaborn for visualization
- Scikit-learn for preprocessing and modeling
- XGBoost for experimental gradient boosting
- Logistic Regression as Base Model
- Decision Tree and Ensemble models as performance Model